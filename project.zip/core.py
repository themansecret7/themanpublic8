"""Serverless Discord-style chat core, modelled on Briar's Bramble stack.

Briar ideas reused here:
  * no central server; identity = Ed25519 keypair, contacts added by exchanging keys
  * every message is signed by its author; message id = hash of content
  * a "group" id is the hash of its descriptor (owner key + nonce)
  * store-and-forward sync: peers swap OFFER (ids) -> REQUEST (ids) -> MESSAGE
  * pluggable transports (LAN TCP, direct address, Tor/.onion via a SOCKS proxy)
  * transport streams are encrypted + authenticated (ephemeral Curve25519 + Ed25519 sigs)
"""
import os, json, time, socket, struct, threading, hashlib, sqlite3, base64, select
from nacl.signing import SigningKey, VerifyKey
from nacl.public import PrivateKey, PublicKey, Box

PORT, BEACON_PORT = 7777, 7778
MAX_FRAME, MAX_BODY = 256 * 1024, 32 * 1024


def h16(b): return hashlib.blake2b(b, digest_size=16).digest()
def canon(d): return json.dumps(d, sort_keys=True, separators=(',', ':')).encode()
def mid(m): return h16(canon(m)).hex()


def socks5(host, port, proxy=('127.0.0.1', 9050)):
    """Connect through Tor/Orbot's SOCKS5 proxy (needed for .onion addresses)."""
    s = socket.create_connection(proxy, 15)
    s.settimeout(90)
    s.sendall(b'\x05\x01\x00')
    if s.recv(2) != b'\x05\x00': raise OSError('socks auth')
    hb = host.encode()
    s.sendall(b'\x05\x01\x00\x03' + bytes([len(hb)]) + hb + struct.pack('>H', port))
    r = s.recv(4)
    if len(r) < 4 or r[1] != 0: raise OSError('socks connect failed')
    skip = {1: 6, 4: 18}.get(r[3])
    if skip is None: skip = s.recv(1)[0] + 2
    s.recv(skip)
    return s


class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.lk = threading.RLock()
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT);
        CREATE TABLE IF NOT EXISTS contacts(pk TEXT PRIMARY KEY, name TEXT, addr TEXT);
        CREATE TABLE IF NOT EXISTS groups(id TEXT PRIMARY KEY, owner TEXT, info TEXT, info_t INTEGER);
        CREATE TABLE IF NOT EXISTS msgs(id TEXT PRIMARY KEY, gid TEXT, ch TEXT, t INTEGER, kind TEXT, raw TEXT);
        CREATE INDEX IF NOT EXISTS mi ON msgs(gid, ch, t);""")

    def q(self, sql, a=()):
        with self.lk:
            cur = self.db.execute(sql, a)
            self.db.commit()
            return cur.fetchall()


class Session(threading.Thread):
    """One encrypted connection to one contact, over any transport."""

    def __init__(self, node, sock, initiated):
        super().__init__(daemon=True)
        self.n, self.sock, self.initiated = node, sock, initiated
        self.alive, self.peer, self.box, self.init_pk = True, None, None, ''
        self.wl = threading.Lock()

    def _tx(self, b):
        with self.wl:
            self.sock.sendall(struct.pack('>I', len(b)) + b)

    def _rx(self, n):
        buf = b''
        while len(buf) < n:
            c = self.sock.recv(n - len(buf))
            if not c: raise ConnectionError
            buf += c
        return buf

    def _frame(self):
        n = struct.unpack('>I', self._rx(4))[0]
        if n > MAX_FRAME: raise ValueError('frame too big')
        return self._rx(n)

    def send(self, obj):
        try: self._tx(self.box.encrypt(canon(obj)))
        except Exception: self.close()

    def close(self):
        self.alive = False
        try: self.sock.close()
        except Exception: pass

    def run(self):
        try:
            self.sock.settimeout(30)
            esk = PrivateKey.generate()
            epk = esk.public_key.encode()
            self._tx(canon({'pk': self.n.pk, 'e': epk.hex(),
                            'sig': self.n.sk.sign(b'dcp2p1' + epk).signature.hex()}))
            hs = json.loads(self._frame())
            peer, pe = hs['pk'], bytes.fromhex(hs['e'])
            VerifyKey(bytes.fromhex(peer)).verify(b'dcp2p1' + pe, bytes.fromhex(hs['sig']))
            if peer == self.n.pk or not self.n.is_contact(peer): return
            self.peer, self.box = peer, Box(esk, PublicKey(pe))
            self.init_pk = self.n.pk if self.initiated else peer
            if not self.n.register(self): return
            ids = self.n.ids_for(peer)
            for i in range(0, len(ids), 500):
                self.send({'t': 'offer', 'ids': ids[i:i + 500]})
            self.loop()
        except Exception:
            pass
        finally:
            self.close()
            if self.peer: self.n.unregister(self)

    def loop(self):
        last = time.time()
        while self.alive:
            r, _, _ = select.select([self.sock], [], [], 20)
            if not r:
                if time.time() - last > 75: break
                self.send({'t': 'ping'})
                continue
            last = time.time()
            m = json.loads(self.box.decrypt(self._frame()))
            t = m.get('t')
            if t == 'offer':
                need = [i for i in m['ids'][:2000] if not self.n.has(i)]
                if need: self.send({'t': 'req', 'ids': need})
            elif t == 'req':
                for raw in self.n.fetch(self.peer, m['ids'][:2000]):
                    self.send({'t': 'msg', 'm': raw})
            elif t == 'msg':
                self.n.accept(m['m'], self.peer)


class Node:
    def __init__(self, datadir, on_event=lambda *a: None, port=PORT, beacon=True):
        os.makedirs(datadir, exist_ok=True)
        self.st, self.ev, self.port, self.beacon = Store(os.path.join(datadir, 'dcp2p.db')), on_event, port, beacon
        self.sessions, self.slk, self.alk = {}, threading.RLock(), threading.RLock()
        self.dialed = {}
        r = self.st.q("SELECT v FROM kv WHERE k='sk'")
        if r:
            self.sk = SigningKey(bytes.fromhex(r[0][0]))
        else:
            self.sk = SigningKey.generate()
            self.st.q("INSERT INTO kv VALUES('sk',?)", (self.sk.encode().hex(),))
        self.pk = self.sk.verify_key.encode().hex()
        r = self.st.q("SELECT v FROM kv WHERE k='name'")
        self.name = r[0][0] if r else 'user-' + self.pk[:4]

    # ---- identity & contacts ------------------------------------------
    def set_name(self, name):
        self.name = name.strip()[:32] or self.name
        self.st.q("INSERT OR REPLACE INTO kv VALUES('name',?)", (self.name,))

    def link(self):
        return 'dcp2p:' + base64.urlsafe_b64encode(canon({'n': self.name, 'pk': self.pk})).decode()

    def add_contact(self, link, addr=''):
        d = json.loads(base64.urlsafe_b64decode(link.strip().removeprefix('dcp2p:')))
        pk = d['pk']
        if len(bytes.fromhex(pk)) != 32: raise ValueError('bad key')
        if pk == self.pk: raise ValueError('that is your own link')
        self.st.q("INSERT OR REPLACE INTO contacts VALUES(?,?,?)", (pk, str(d['n'])[:32], addr.strip()))
        self.ev('contacts')
        return pk

    def set_addr(self, pk, addr):
        self.st.q("UPDATE contacts SET addr=? WHERE pk=?", (addr.strip(), pk))
        self.ev('contacts')

    def contacts(self):
        return [{'pk': p, 'name': n, 'addr': a, 'online': p in self.sessions}
                for p, n, a in self.st.q("SELECT pk,name,addr FROM contacts ORDER BY name")]

    def is_contact(self, pk): return bool(self.st.q("SELECT 1 FROM contacts WHERE pk=?", (pk,)))

    def contact_by_hash(self, hx):
        for c in self.contacts():
            if h16(bytes.fromhex(c['pk'])).hex() == hx: return c['pk']

    # ---- servers (groups) ---------------------------------------------
    def servers(self):
        out = []
        for gid, owner, info in self.st.q("SELECT id,owner,info FROM groups ORDER BY rowid"):
            i = json.loads(info)
            out.append({'id': gid, 'owner': owner, 'name': i['name'], 'channels': i['channels'], 'members': i['members']})
        return out

    def server(self, gid):
        return next((s for s in self.servers() if s['id'] == gid), None)

    def _sign(self, m):
        m.update(a=self.pk, t=int(time.time() * 1000))
        m['s'] = self.sk.sign(canon(m)).signature.hex()
        return m

    def _publish_info(self, gid, info):
        self.accept(self._sign({'g': gid, 'c': '', 'k': 'info', 'b': info}), None)

    def create_server(self, name):
        nonce = os.urandom(8).hex()
        gid = h16(bytes.fromhex(self.pk) + bytes.fromhex(nonce)).hex()
        self._publish_info(gid, {'owner': self.pk, 'nonce': nonce, 'name': name[:40] or 'server',
                                 'channels': ['general'], 'members': [{'pk': self.pk, 'n': self.name}]})
        return gid

    def _owned(self, gid):
        g = self.server(gid)
        if not g or g['owner'] != self.pk: raise PermissionError('only the server owner can do this')
        return g

    def _info(self, g, nonce_src):
        row = self.st.q("SELECT info FROM groups WHERE id=?", (g['id'],))
        return json.loads(row[0][0])

    def add_channel(self, gid, ch):
        g = self._owned(gid)
        ch = ch.strip().lower().replace(' ', '-')[:32]
        if not ch or ch in g['channels'] or len(g['channels']) >= 50: return
        i = self._info(g, None)
        i['channels'] = g['channels'] + [ch]
        self._publish_info(gid, i)

    def invite(self, gid, pk):
        g = self._owned(gid)
        c = next((c for c in self.contacts() if c['pk'] == pk), None)
        if not c or any(m['pk'] == pk for m in g['members']): return
        i = self._info(g, None)
        i['members'] = g['members'] + [{'pk': pk, 'n': c['name']}]
        self._publish_info(gid, i)

    def post(self, gid, ch, text):
        self.accept(self._sign({'g': gid, 'c': ch, 'k': 'chat', 'b': text[:8000]}), None)

    def history(self, gid, ch, limit=200):
        rows = self.st.q("SELECT raw FROM msgs WHERE gid=? AND ch=? AND kind='chat' ORDER BY t DESC LIMIT ?", (gid, ch, limit))
        return [json.loads(r[0]) for r in reversed(rows)]

    # ---- sync ----------------------------------------------------------
    def has(self, i): return bool(self.st.q("SELECT 1 FROM msgs WHERE id=?", (i,)))

    def ids_for(self, pk):
        out = []
        for g in self.servers():
            if any(m['pk'] == pk for m in g['members']):
                out += [r[0] for r in self.st.q(
                    "SELECT id FROM msgs WHERE gid=? ORDER BY (kind='info') DESC, t", (g['id'],))]
        return out

    def fetch(self, pk, ids):
        mem = {g['id'] for g in self.servers() if any(m['pk'] == pk for m in g['members'])}
        out = []
        for i in ids:
            r = self.st.q("SELECT gid, kind, raw FROM msgs WHERE id=?", (i,))
            if r and r[0][0] in mem: out.append((r[0][1] != 'info', json.loads(r[0][2])))
        return [m for _, m in sorted(out, key=lambda x: x[0])]

    def accept(self, m, frm):
        """Validate (signature, group rules), store, notify UI, relay to other members."""
        with self.alk:
            try:
                if len(json.dumps(m)) > MAX_BODY + 4096: return False
                body = {k: v for k, v in m.items() if k != 's'}
                VerifyKey(bytes.fromhex(m['a'])).verify(canon(body), bytes.fromhex(m['s']))
                gid, kind, t, i = m['g'], m['k'], int(m['t']), mid(m)
                if self.has(i): return False
                if kind == 'info':
                    b = m['b']
                    if h16(bytes.fromhex(b['owner']) + bytes.fromhex(b['nonce'])).hex() != gid or m['a'] != b['owner']: return False
                    if not (isinstance(b['channels'], list) and len(b['channels']) <= 50 and isinstance(b['name'], str)
                            and all(isinstance(c, str) and len(c) <= 32 for c in b['channels'])
                            and len(b['members']) <= 500): return False
                    row = self.st.q("SELECT info_t FROM groups WHERE id=?", (gid,))
                    if not row and self.pk not in [x['pk'] for x in b['members']]: return False
                    if row and row[0][0] >= t: return False
                    self.st.q("DELETE FROM msgs WHERE gid=? AND kind='info'", (gid,))
                    self.st.q("INSERT OR REPLACE INTO groups VALUES(?,?,?,?)", (gid, b['owner'], json.dumps(b), t))
                else:
                    g = self.server(gid)
                    if kind != 'chat' or not g or m['a'] not in [x['pk'] for x in g['members']]: return False
                    if not isinstance(m['b'], str) or len(m['b'].encode()) > MAX_BODY or not isinstance(m['c'], str): return False
                self.st.q("INSERT INTO msgs VALUES(?,?,?,?,?,?)", (i, gid, m['c'], t, kind, json.dumps(m)))
            except Exception:
                return False
        self.ev('group' if kind == 'info' else 'msg', gid)
        mem = {x['pk'] for x in self.server(gid)['members']}
        with self.slk: ss = list(self.sessions.items())
        for pk, s in ss:
            if pk in mem and pk != frm: s.send({'t': 'offer', 'ids': [i]})
        return True

    # ---- sessions & transports ----------------------------------------
    def register(self, s):
        with self.slk:
            old = self.sessions.get(s.peer)
            if old and old.alive:
                if not s.init_pk < old.init_pk: return False   # both sides keep the same one
                old.close()
            self.sessions[s.peer] = s
        self.ev('contacts')
        return True

    def unregister(self, s):
        with self.slk:
            if self.sessions.get(s.peer) is s: del self.sessions[s.peer]
        self.ev('contacts')

    def dial(self, host, port):
        try:
            sock = socks5(host, port) if host.endswith('.onion') else socket.create_connection((host, port), 8)
            Session(self, sock, True).start()
        except OSError:
            pass

    def start(self):
        for f in [self._listen, self._manual] + ([self._beacon_tx, self._beacon_rx] if self.beacon else []):
            threading.Thread(target=f, daemon=True).start()

    # LAN TCP plugin: listen + UDP broadcast beacons to find contacts on the same Wi-Fi
    def _listen(self):
        srv = socket.socket()
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(('', self.port))
        srv.listen(8)
        while True:
            c, _ = srv.accept()
            Session(self, c, False).start()

    def _beacon_tx(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        msg = canon({'id': h16(bytes.fromhex(self.pk)).hex(), 'p': self.port})
        while True:
            try: s.sendto(msg, ('255.255.255.255', BEACON_PORT))
            except OSError: pass
            time.sleep(5)

    def _beacon_rx(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(('', BEACON_PORT))
        while True:
            try:
                data, (ip, _) = s.recvfrom(512)
                d = json.loads(data)
                pk = self.contact_by_hash(d['id'])
                if pk and pk not in self.sessions and self.pk < pk and time.time() - self.dialed.get(pk, 0) > 10:
                    self.dialed[pk] = time.time()
                    threading.Thread(target=self.dial, args=(ip, int(d['p'])), daemon=True).start()
            except Exception:
                pass

    # Direct-address plugin: "host:port" or "xyz.onion:port" (Tor via Orbot SOCKS on 127.0.0.1:9050)
    def _manual(self):
        while True:
            for c in self.contacts():
                if c['addr'] and c['pk'] not in self.sessions:
                    host, _, port = c['addr'].rpartition(':') if ':' in c['addr'] else (c['addr'], '', str(PORT))
                    try: threading.Thread(target=self.dial, args=(host, int(port)), daemon=True).start()
                    except ValueError: pass
            time.sleep(15)

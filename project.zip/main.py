import time
from kivy.app import App
from kivy.lang import Builder
from kivy.clock import Clock, mainthread
from kivy.core.clipboard import Clipboard
from kivy.core.window import Window
from kivy.factory import Factory
from kivy.metrics import dp
from kivy.utils import platform, escape_markup
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from core import Node

KV = """
<Row@Button>:
    size_hint_y: None
    height: dp(52)
    halign: 'left'
    valign: 'middle'
    text_size: self.width - dp(20), self.height
    background_normal: ''
    background_color: .27, .28, .32, 1
<Msg@Label>:
    size_hint_y: None
    text_size: self.width, None
    height: self.texture_size[1] + dp(4)
    markup: True
    halign: 'left'
<Bar@Button>:
    background_normal: ''
    background_color: .35, .4, .95, 1

BoxLayout:
    orientation: 'vertical'
    ScreenManager:
        id: sm
        Screen:
            name: 'servers'
            BoxLayout:
                orientation: 'vertical'
                padding: dp(8)
                spacing: dp(6)
                Label:
                    text: 'Servers'
                    bold: True
                    size_hint_y: None
                    height: dp(36)
                ScrollView:
                    BoxLayout:
                        id: servers
                        orientation: 'vertical'
                        size_hint_y: None
                        height: self.minimum_height
                        spacing: dp(4)
                Bar:
                    text: '+ New server'
                    size_hint_y: None
                    height: dp(48)
                    on_release: app.new_server()
        Screen:
            name: 'contacts'
            BoxLayout:
                orientation: 'vertical'
                padding: dp(8)
                spacing: dp(6)
                Label:
                    text: 'Contacts (tap to set address)'
                    bold: True
                    size_hint_y: None
                    height: dp(36)
                ScrollView:
                    BoxLayout:
                        id: contacts
                        orientation: 'vertical'
                        size_hint_y: None
                        height: self.minimum_height
                        spacing: dp(4)
                Bar:
                    text: '+ Add contact'
                    size_hint_y: None
                    height: dp(48)
                    on_release: app.add_contact()
        Screen:
            name: 'chat'
            BoxLayout:
                orientation: 'vertical'
                BoxLayout:
                    size_hint_y: None
                    height: dp(44)
                    Button:
                        text: '<'
                        size_hint_x: None
                        width: dp(44)
                        on_release: app.go('servers')
                    Label:
                        id: title
                        shorten: True
                        text_size: self.width, None
                    Spinner:
                        id: chan
                        size_hint_x: None
                        width: dp(110)
                        on_text: app.pick_channel(self.text)
                    Button:
                        text: '+#'
                        size_hint_x: None
                        width: dp(40)
                        on_release: app.new_channel()
                    Button:
                        text: 'Invite'
                        size_hint_x: None
                        width: dp(64)
                        on_release: app.invite()
                ScrollView:
                    id: scroll
                    BoxLayout:
                        id: msgs
                        orientation: 'vertical'
                        size_hint_y: None
                        height: self.minimum_height
                        padding: dp(6)
                        spacing: dp(4)
                BoxLayout:
                    size_hint_y: None
                    height: dp(48)
                    TextInput:
                        id: inp
                        hint_text: 'Message'
                        multiline: False
                        on_text_validate: app.send()
                    Bar:
                        text: 'Send'
                        size_hint_x: None
                        width: dp(70)
                        on_release: app.send()
        Screen:
            name: 'me'
            BoxLayout:
                orientation: 'vertical'
                padding: dp(8)
                spacing: dp(6)
                Label:
                    text: 'Display name'
                    size_hint_y: None
                    height: dp(30)
                TextInput:
                    id: myname
                    multiline: False
                    size_hint_y: None
                    height: dp(44)
                Bar:
                    text: 'Save name'
                    size_hint_y: None
                    height: dp(44)
                    on_release: app.save_name()
                Label:
                    text: 'Your contact link - send it to friends'
                    size_hint_y: None
                    height: dp(30)
                TextInput:
                    id: mylink
                    readonly: True
                Bar:
                    text: 'Copy link'
                    size_hint_y: None
                    height: dp(44)
                    on_release: app.copy_link()
    BoxLayout:
        size_hint_y: None
        height: dp(48)
        Button:
            text: 'Servers'
            on_release: app.go('servers')
        Button:
            text: 'Contacts'
            on_release: app.go('contacts')
        Button:
            text: 'Me'
            on_release: app.go('me')
"""


class DiscApp(App):
    gid = ch = None

    def build(self):
        Window.clearcolor = (.21, .22, .25, 1)
        Window.softinput_mode = 'below_target'
        Window.bind(on_keyboard=self.on_key)
        self.node = Node(self.user_data_dir, self.on_event)
        self.ui = Builder.load_string(KV)
        return self.ui

    def on_start(self):
        self.multicast_lock()
        self.node.start()
        self.ui.ids.myname.text = self.node.name
        self.ui.ids.mylink.text = self.node.link()
        self.refresh_servers()
        self.refresh_contacts()

    def on_pause(self): return True

    def multicast_lock(self):  # lets Android deliver UDP broadcast beacons
        if platform != 'android': return
        try:
            from jnius import autoclass
            ctx = autoclass('org.kivy.android.PythonActivity').mActivity
            wifi = ctx.getSystemService(autoclass('android.content.Context').WIFI_SERVICE)
            self._ml = wifi.createMulticastLock('dc')
            self._ml.acquire()
        except Exception as e:
            print('multicast lock failed', e)

    def on_key(self, win, key, *a):
        if key == 27 and self.ui.ids.sm.current != 'servers':   # Android back button
            self.go('servers')
            return True

    # ---- node events arrive on worker threads --------------------------
    def on_event(self, kind, *a): self.handle(kind, *a)

    @mainthread
    def handle(self, kind, gid=None):
        if kind == 'contacts': self.refresh_contacts()
        elif kind == 'group':
            self.refresh_servers()
            if gid == self.gid: self.open_server(gid, keep=True)
        elif kind == 'msg' and gid == self.gid: self.render()

    def go(self, name): self.ui.ids.sm.current = name

    # ---- dialogs -------------------------------------------------------
    def ask(self, title, fields, cb):
        box = BoxLayout(orientation='vertical', spacing=dp(8), padding=dp(8))
        tis = [TextInput(hint_text=f, multiline=False, size_hint_y=None, height=dp(44)) for f in fields]
        for t in tis: box.add_widget(t)
        row = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(8))
        p = Popup(title=title, content=box, size_hint=(.94, None), height=dp(150 + 52 * len(fields)),
                  pos_hint={'top': .98})
        def ok(*_):
            p.dismiss()
            self.safely(cb, *[t.text.strip() for t in tis])
        b1, b2 = Button(text='OK'), Button(text='Cancel')
        b1.bind(on_release=ok)
        b2.bind(on_release=p.dismiss)
        row.add_widget(b1); row.add_widget(b2)
        box.add_widget(row)
        p.open()
        if tis: Clock.schedule_once(lambda dt: setattr(tis[0], 'focus', True), .2)

    def choose(self, title, options, cb):
        box = BoxLayout(orientation='vertical', spacing=dp(4), padding=dp(8), size_hint_y=None)
        box.bind(minimum_height=box.setter('height'))
        p = Popup(title=title, content=ScrollView(do_scroll_x=False), size_hint=(.94, .6))
        for label, val in options:
            b = Factory.Row(text=label)
            b.bind(on_release=lambda _, v=val: (p.dismiss(), self.safely(cb, v)))
            box.add_widget(b)
        p.content.add_widget(box)
        p.open()

    def note(self, msg):
        Popup(title='', content=Label(text=msg, text_size=(dp(280), None), halign='center'),
              size_hint=(.9, .3)).open()

    def safely(self, fn, *a):
        try: fn(*a)
        except Exception as e: self.note(str(e) or type(e).__name__)

    # ---- servers / channels -------------------------------------------
    def new_server(self):
        self.ask('New server', ['Server name'], lambda n: n and self.node.create_server(n))

    def refresh_servers(self):
        box = self.ui.ids.servers
        box.clear_widgets()
        for s in self.node.servers():
            r = Factory.Row(text=f"{s['name']}   ({len(s['members'])} members)")
            r.bind(on_release=lambda _, g=s['id']: self.open_server(g))
            box.add_widget(r)

    def open_server(self, gid, keep=False):
        g = self.node.server(gid)
        if not g: return
        self.gid = gid
        self.ui.ids.title.text = g['name']
        self.ui.ids.chan.values = ['#' + c for c in g['channels']]
        want = '#' + self.ch if keep and self.ch in g['channels'] else '#' + g['channels'][0]
        self.ui.ids.chan.text = want
        self.ch = want[1:]
        self.render()
        self.go('chat')

    def pick_channel(self, text):
        if text and self.gid:
            self.ch = text.lstrip('#')
            self.render()

    def new_channel(self):
        self.ask('New channel', ['channel-name'], lambda n: n and self.node.add_channel(self.gid, n))

    def invite(self):
        have = {m['pk'] for m in self.node.server(self.gid)['members']}
        opts = [(c['name'], c['pk']) for c in self.node.contacts() if c['pk'] not in have]
        if not opts: return self.note('No contacts to invite. Add contacts first.')
        self.choose('Invite contact', opts, lambda pk: self.node.invite(self.gid, pk))

    # ---- chat ----------------------------------------------------------
    def render(self):
        g = self.node.server(self.gid)
        if not g: return
        names = {m['pk']: m['n'] for m in g['members']}
        box = self.ui.ids.msgs
        box.clear_widgets()
        for m in self.node.history(self.gid, self.ch):
            who = escape_markup(names.get(m['a'], m['a'][:6]))
            when = time.strftime('%H:%M', time.localtime(m['t'] / 1000))
            box.add_widget(Factory.Msg(
                text=f"[b]{who}[/b] [size=11sp][color=999999]{when}[/color][/size]\n{escape_markup(m['b'])}"))
        Clock.schedule_once(lambda dt: setattr(self.ui.ids.scroll, 'scroll_y', 0), .1)

    def send(self):
        t = self.ui.ids.inp.text.strip()
        if t and self.gid and self.ch:
            self.node.post(self.gid, self.ch, t)
            self.ui.ids.inp.text = ''
            Clock.schedule_once(lambda dt: setattr(self.ui.ids.inp, 'focus', True), .1)

    # ---- contacts / profile -------------------------------------------
    def refresh_contacts(self):
        box = self.ui.ids.contacts
        box.clear_widgets()
        for c in self.node.contacts():
            r = Factory.Row(text=f"{'[online]' if c['online'] else '[offline]'} {c['name']}   {c['addr']}")
            r.bind(on_release=lambda _, c=c: self.ask(f"Address for {c['name']}", ['host:port or xyz.onion:7777 (blank = LAN only)'],
                                                      lambda a: self.node.set_addr(c['pk'], a)))
            box.add_widget(r)

    def add_contact(self):
        self.ask('Add contact', ['Paste their dcp2p: link', 'Address (optional)'],
                 lambda link, addr: self.node.add_contact(link, addr))

    def save_name(self):
        self.node.set_name(self.ui.ids.myname.text)
        self.ui.ids.mylink.text = self.node.link()

    def copy_link(self):
        Clipboard.copy(self.node.link())
        self.note('Link copied')


DiscApp().run()
